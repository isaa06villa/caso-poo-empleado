export class RepositorioEmpleado {
  constructor() {
    this.empleados = []
  }

  addEmpleado(empleado) {
    this.empleados.push(empleado)
  }

}
