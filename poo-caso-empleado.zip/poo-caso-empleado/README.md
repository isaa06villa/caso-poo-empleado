# poo-caso-empleado
POO orientada a objetos ejercicio 1

Se quiere una aplicación que permita manejar la información de un empleado.
Del empleado se maneja la siguiente información:

Nombre
Apellido
 Género (femenino o masculino).
 Fecha de nacimiento.
 Foto
 Fecha de ingreso a la empresa
 Salario básico.
La aplicación permite visualizar la información del empleado, y hacer los siguientes cálculos:
 Edad del empleado, utilizando la fecha de nacimiento del empleado.
 Antigüedad del empleado, utilizando la fecha de ingreso del empleado.
 Prestaciones a las que tiene derecho el empleado. Para este cálculo se debe usar la
siguiente fórmula:
